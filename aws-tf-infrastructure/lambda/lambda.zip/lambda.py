import json
import boto3
from botocore.exceptions import BotoCoreError, ClientError
import base64

def lambda_handler(event, context):
    try:
        text = event.get("text")
        voice = event.get("voice")
        language = event.get("language")
        engine = event.get("engine", "standard")  # Default to 'standard' engine
        
        # Validate required parameters
        if not text or not voice or not language:
            return {
                "statusCode": 400,
                "body": json.dumps({"error": "Missing required parameters (text, voice, language)."})
            }
        
        # Initialize the Polly client
        polly = boto3.client("polly")
        
        # Synthesize speech
        response = polly.synthesize_speech(
            Text=text,
            OutputFormat="mp3",
            VoiceId=voice,
            Engine=engine,
            LanguageCode=language
        )
        
        # Retrieve the audio stream
        audio_stream = response.get("AudioStream")
        if not audio_stream:
            return {
                "statusCode": 500,
                "body": json.dumps({"error": "Failed to synthesize speech."})
            }
        
        # Convert audio stream to base64 for inclusion in the HTTP response
        audio_base64 = base64.b64encode(audio_stream.read()).decode("utf-8")
        
        # Return the MP3 file as base64-encoded string
        return {
            "statusCode": 200,
            "headers": {
                "Content-Type": "application/json"
            },
            "body": json.dumps({
                "audio": audio_base64
            })
        }
    except (BotoCoreError, ClientError) as e:
        # Handle AWS SDK errors
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)})
        }
    except Exception as e:
        # Handle other exceptions
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)})
        }
